## konas memed by christallinqq

**READ THIS**

This crack is extremely chinese. Basically since 0.5.2 or something Konas devs started using reflections which is a shit library.
You'll probably have to load the game up a few times before any modules actually load, but once the game loads every module works normally.
Configs may not save either, so its suggested you use .config save <name> so you have configs to load up in the event your config gets reset.

**HOW TO USE**

Put Konas-b0.8.jar in your mods folder, and konas.jar in your .minecraft, NOT your mods folder.
This will be merged into a single jar at a later date but the people in the Konas discord were so insistent that we release it as is, so here we are.

We had literally no reason to release this other than Crystallinqq being cringe.
We have nothing against the Konas devs they seem pretty chill but their security needs some work :P

![cope](https://cdn.discordapp.com/attachments/810380169109045278/812539718482001920/unknown.png)
